import LogIn from './index.vue';

export default {
    path: '/LogIn',
    name: 'LogIn',
    component:  LogIn,
}