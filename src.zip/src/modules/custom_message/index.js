import dashBoardRoute from './route';

export {
    dashBoardRoute as route
}
