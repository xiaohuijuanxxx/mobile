import start from './startUp.vue';

export default{
    path: '/start',
    name: 'start',
    component: start
}
