export const logger = function(log){
    console.log(log)
}